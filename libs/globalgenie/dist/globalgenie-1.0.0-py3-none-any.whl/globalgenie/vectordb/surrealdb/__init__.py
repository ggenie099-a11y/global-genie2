from globalgenie.vectordb.surrealdb.surrealdb import SurrealDb

__all__ = ["SurrealDb"]

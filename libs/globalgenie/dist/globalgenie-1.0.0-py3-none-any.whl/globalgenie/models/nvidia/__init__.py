from globalgenie.models.nvidia.nvidia import Nvidia

__all__ = [
    "Nvidia",
]

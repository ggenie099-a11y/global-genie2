from globalgenie.document.reader.base import Reader

__all__ = [
    "Reader",
]

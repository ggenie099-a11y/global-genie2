from globalgenie.models.langdb.langdb import LangDB

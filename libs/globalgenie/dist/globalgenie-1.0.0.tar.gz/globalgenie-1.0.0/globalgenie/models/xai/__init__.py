from globalgenie.models.xai.xai import xAI

__all__ = ["xAI"]

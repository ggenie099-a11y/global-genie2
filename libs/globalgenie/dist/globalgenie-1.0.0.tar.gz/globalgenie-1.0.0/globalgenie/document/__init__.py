from globalgenie.document.base import Document

__all__ = [
    "Document",
]

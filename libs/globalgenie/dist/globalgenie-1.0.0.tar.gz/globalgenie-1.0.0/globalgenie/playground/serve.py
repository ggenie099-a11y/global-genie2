from globalgenie.app.playground.serve import serve_playground_app

__all__ = ["serve_playground_app"]

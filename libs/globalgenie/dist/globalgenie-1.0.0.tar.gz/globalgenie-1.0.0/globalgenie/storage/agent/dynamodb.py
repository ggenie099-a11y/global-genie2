from globalgenie.storage.dynamodb import DynamoDbStorage as DynamoDbAgentStorage  # noqa: F401
